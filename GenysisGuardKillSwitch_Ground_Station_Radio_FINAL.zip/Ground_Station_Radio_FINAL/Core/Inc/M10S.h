#ifndef M10S_UBX_NAV_POSLLH_H
#define M10S_UBX_NAV_POSLLH_H

#include <stdint.h> // For standard integer types
#include "main.h"

typedef struct _M10S_UBX_NAV_POSLLH

{
    uint8_t CLASS; //Identification field of the UBX message.
    uint8_t ID; //Identification field of the UBX message.
    uint16_t length;//length of the UBX message in bytes
    uint32_t iTOW;//Data field extracted from the UBX message.
    int32_t longitude; //Longitude extracted from the UBX meaage.
    int32_t latitude;//Latitude extracted from the UBX meaage.
    int32_t altitude;//Altitude in ellipsoid.
    int32_t hMSL;
    uint32_t hAcc;
    uint32_t vAcc;
    double longitude_f64;
    double latitude_f64;

} M10S_UBX_NAV_POSLLH;


extern M10S_UBX_NAV_POSLLH posllh_structure_variable; //extern is used here so the structure variable "posllh" is accessible in main.c


uint8_t M10S_UBX_CHKSUM_Check(uint8_t* UBX_data, uint8_t UBX_message_length);
void M10S_UBX_NAV_POSLLH_Parsing(uint8_t* UBX_data, M10S_UBX_NAV_POSLLH* posllh);
void M10S_TransmitData(unsigned char* UBX_data, unsigned char UBX_message_length);
void M10S_USART1_Initialization(void);
void M10S_Initialization(void);

#endif
