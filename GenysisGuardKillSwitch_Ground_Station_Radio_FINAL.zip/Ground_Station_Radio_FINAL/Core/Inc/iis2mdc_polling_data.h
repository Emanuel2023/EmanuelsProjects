/*
 * iis2mdc_polling_data.h
 *
 *  Created on: Oct 24, 2024
 *      Author: super
 */

#ifndef INC_IIS2MDC_POLLING_DATA_H_
#define INC_IIS2MDC_POLLING_DATA_H_

#include "main.h"
#include <string.h>
#include <stdio.h>
#include "iis2mdc_reg.h"

#define		BOOT_TIME	20 //ms

typedef enum iis2mdc_status{
	IIS2MDC_OK,
	IIS2MDC_ERROR
}iis2mdc_status_e;

typedef struct iis2mdc_data{
	float magnetX;
	float magnetY;
	float magnetZ;
	float temp;
	uint8_t data_ready;
} iis2mdc_data_t;

iis2mdc_status_e iis2mdcInit(stmdev_ctx_t *dev_ctx);
iis2mdc_data_t iis2mdc_read_data(stmdev_ctx_t *dev_ctx);
int32_t platform_write(void *handle, uint8_t reg, const uint8_t *bufp, uint16_t len);
int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp, uint16_t len);
void platform_delay(uint32_t ms);

#endif /* INC_IIS2MDC_POLLING_DATA_H_ */
