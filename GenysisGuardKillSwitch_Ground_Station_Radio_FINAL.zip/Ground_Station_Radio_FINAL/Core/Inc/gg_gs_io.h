/*
 * GG_GS_IO.h
 *
 *  Created on: Sep 11, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 */

#ifndef INC_GG_GS_IO_H_
#define INC_GG_GS_IO_H_

#include "main.h"

/*
 * @brief:	Definitions that assign HAL the GPIO definitions to the library
 */
#define ENCODER_CHANNEL_A_PIN	ChanA_encoder_Pin
#define ENCODER_BUTTON_PIN		Button_Pin
#define EMERGENCY_STOP_PIN		Estop_Pin

typedef enum gpioGsEnum{
	none,				/*!< Return status of none in the event of variable
	 	 	 	 	 	 	 initialization or if the triggered interrupt is
							 not within the bounds of the library*/

	CwTurn,				/*!< Return status of CwTurn in the event of the
	 	 	 	 	 	 	 gpioFSM function detecting a clockwise turn*/

	CCwTurn,			/*!< Return status of CCwTurn in the event of the
	 	 	 	 	 	 	 gpioFSM function detecting a counterclockwise
	 	 	 	 	 	 	 turn*/

	enter,				/*!< Return status of enter in the event of the
	 	 	 	 	 	 	 gpioFSM function detecting an encoder button
	 	 	 	 	 	 	 press*/

	Estop				/*!< Return status of Estop in the event of the
	 	 	 	 	 	 	 gpioFSM function detecting an emergency stop
	 	 	 	 	 	 	 button press*/
}gpioGsEnum_e;

typedef struct gsIO{
	GPIO_TypeDef *GPIOx;/*!< The GPIO port of the associated channel*/

	uint16_t GPIO_Pin;	/*!< The GPIO pin of the associated channel*/
}gsIO_s;


void encChanAInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void encChanBInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void encChanBtnInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void eStopInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
gpioGsEnum_e gpioGsFSM(uint16_t channel);

#endif /* INC_GG_GS_IO_H_ */
