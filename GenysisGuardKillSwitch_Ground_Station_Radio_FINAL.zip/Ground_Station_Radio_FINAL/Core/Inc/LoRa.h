/*
 * LoRa.h
 *
 *  Created on: Mar 6, 2024
 *      Author: super
 */

#ifndef INC_LORA_H_
#define INC_LORA_H_

#include "main.h"
#include "cmsis_os.h"
#include "app_subghz_phy.h"
#include "radio_def.h"

/* Uncomment the appropriate define statement for the device */
#define DEVICE_ID Ground_Station
//#define DEVICE_ID On_Board

/*RTOS Message Queue external variable declaration*/
extern osMessageQueueId_t messageQueueHandle;

/*Framework for adding more devices*/
enum Identification_Number {Ground_Station, On_Board};
enum Message {Init, HS, Heartbeat, Arm, Reset, next_state, ns_ack, recover};
enum state {s1,s2,s3,s4};

/*Structure to nicely package data that will be exchanged*/

#pragma pack(1)
typedef struct lora_msg_s{
	enum Identification_Number ID;
	enum Message msg_id;
	enum state state;
	int32_t gps_long;
	int32_t gps_lat;
	uint8_t b_percentage;
	uint16_t b_voltage;
}lora_msg_s;
#pragma pack()

/*Structure to nicely package GPS data*/
typedef struct gps_s{
	uint32_t gps_long_geofence;
	uint32_t gps_lat_geofence;
}gps_s;

//buffer char[100];
//sprintf(buffer, "Long: %32u\n\rLat: %32u\n\rButton State: %i", gps_long, gps_lat, btn);


/*User Functions for LoRa related processes*/
void init();
void heartBeat();
void freqCheck();
void hs();
void ns();
void arm();
void reset();
void getGPS();
void getBLE();
void send_GS_heartbeat();
void processData();	//Input parameters not needed if using a message queue
void getGPS(lora_msg_s *inst);
double getBearing(double lat1, double lon1, double lat2, double lon2);
void display_arrow(double arrow_Direction, double ob_range);
double getRange(double lat1, double lon1, double lat2, double lon2);


#endif /* INC_LORA_H_ */
