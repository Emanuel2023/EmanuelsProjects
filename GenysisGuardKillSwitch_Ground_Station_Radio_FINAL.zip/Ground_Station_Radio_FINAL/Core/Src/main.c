/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  * This is modified to staisfy requirements of Genisys Guard (SENIOR DESIGN). The following changes
  * have been made since last PDR
  * 	Display is configured with getBLEData Function
  * 	States are added and loosely defined (early development)
  * 	Spreading factor was modified (found in radio.h
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "app_subghz_phy.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "LoRa.h"
#include "gg_gs_io.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "VbatADC.h"
#include "M10S.h"
#include "iis2mdc_polling_data.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
int _write(int file, char* p, int UBX_message_length)
{
	int i = 0;
	while ( i < UBX_message_length)
	{
		while (!LL_USART_IsActiveFlag_TXE(USART2));
		LL_USART_TransmitData8(USART2, *(p+i));
		i++;
	}
	return UBX_message_length;
}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define max(a,b) (((a) > (b)) ? (a) : (b))

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

I2C_HandleTypeDef hi2c1;

SUBGHZ_HandleTypeDef hsubghz;

UART_HandleTypeDef huart2;

/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for myTask02 */
osThreadId_t myTask02Handle;
const osThreadAttr_t myTask02_attributes = {
  .name = "myTask02",
  .priority = (osPriority_t) osPriorityLow,
  .stack_size = 128 * 4
};
/* Definitions for blink01 */
osThreadId_t blink01Handle;
const osThreadAttr_t blink01_attributes = {
  .name = "blink01",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for Handshake */
osThreadId_t HandshakeHandle;
const osThreadAttr_t Handshake_attributes = {
  .name = "Handshake",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for Freq_check */
osThreadId_t Freq_checkHandle;
const osThreadAttr_t Freq_check_attributes = {
  .name = "Freq_check",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for HeartBeat */
osThreadId_t HeartBeatHandle;
const osThreadAttr_t HeartBeat_attributes = {
  .name = "HeartBeat",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 256 * 4
};
/* Definitions for Compass */
osThreadId_t CompassHandle;
const osThreadAttr_t Compass_attributes = {
  .name = "Compass",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 256 * 4
};
/* Definitions for messageQueue */
osMessageQueueId_t messageQueueHandle;
const osMessageQueueAttr_t messageQueue_attributes = {
  .name = "messageQueue"
};
/* Definitions for signal */
osMessageQueueId_t signalHandle;
const osMessageQueueAttr_t signal_attributes = {
  .name = "signal"
};
/* USER CODE BEGIN PV */
//////////////////////////////////// initalizes state (MODIFIED CODE FOR SENIOR DESIGN)
uint8_t state = s1;
int8_t counter =0;
char highFreq;
char lowFreq;
int voltageIndex = 0;
int selectedVoltage = -1;
float voltages[6] = {8.4, 12.6, 16.8, 21.0, 25.2, 29.4};
char buffer[100];

iis2mdc_data_t compData;
stmdev_ctx_t compass1;
//int counter =0;
int arraySize = sizeof(voltages) / sizeof(voltages[0]);

/*----------ADC Variables----------*/
battery_s batteryInstance;

/*----------GPIO Variables----------*/
gpioGsEnum_e globPinState = none;

extern uint8_t M10S_received_buffer_RX[36];
extern uint8_t M10S_RX_complete_flag;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC_Init(void);
static void MX_USART1_UART_Init(void);
void StartDefaultTask(void *argument);
void getBLE_Data(void *argument);
void StartBlink(void *argument);
void Handshake_entry(void *argument);
void Freq_check_s2(void *argument);
void HeartBeat_s3(void *argument);
void CompassData(void *argument);

/* USER CODE BEGIN PFP */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();


  /* USER CODE BEGIN Init */
  //init();
  //Initializes Radio
   MX_SubGHz_Phy_Init();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */



  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ADC_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  //////////////////////////////Necessary initializations for I/O Library (CONFIGURES BUTTON AND ROTARY ENCODER)
  encChanAInit(ChanA_encoder_GPIO_Port, ChanA_encoder_Pin);
  encChanBInit(ChanB_Encoder_GPIO_Port, ChanB_Encoder_Pin);
  encChanBtnInit(Button_GPIO_Port, Button_Pin);
  eStopInit(Estop_GPIO_Port, Estop_Pin);


  //////////////////////////INITIALIZES SCREEN (MODIFIED CODE)
  ssd1306_Init();

  iis2mdc_status_e status = iis2mdcInit(&compass1);

  LL_USART_EnableIT_RXNE_RXFNE(USART1);
  LL_USART_EnableIT_RXNE_RXFNE(USART2);

  HAL_Delay(100);
  M10S_Initialization();



  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of messageQueue */
  messageQueueHandle = osMessageQueueNew (16, sizeof(lora_msg_s), &messageQueue_attributes);

  /* creation of signal */
  signalHandle = osMessageQueueNew (16, sizeof(uint16_t), &signal_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of myTask02 */
  myTask02Handle = osThreadNew(getBLE_Data, NULL, &myTask02_attributes);

  /* creation of blink01 */
  blink01Handle = osThreadNew(StartBlink, NULL, &blink01_attributes);

  /* creation of Handshake */
  HandshakeHandle = osThreadNew(Handshake_entry, NULL, &Handshake_attributes);

  /* creation of Freq_check */
  Freq_checkHandle = osThreadNew(Freq_check_s2, NULL, &Freq_check_attributes);

  /* creation of HeartBeat */
  HeartBeatHandle = osThreadNew(HeartBeat_s3, NULL, &HeartBeat_attributes);

  /* creation of Compass */
  CompassHandle = osThreadNew(CompassData, NULL, &Compass_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the SYSCLKSource, HCLK, PCLK1 and PCLK2 clocks dividers
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK3|RCC_CLOCKTYPE_HCLK
                              |RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1
                              |RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK3Divider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC;
  hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.NbrOfConversion = 1;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc.Init.SamplingTimeCommon1 = ADC_SAMPLETIME_1CYCLE_5;
  hadc.Init.SamplingTimeCommon2 = ADC_SAMPLETIME_1CYCLE_5;
  hadc.Init.OversamplingMode = DISABLE;
  hadc.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00100D14;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SUBGHZ Initialization Function
  * @param None
  * @retval None
  */
void MX_SUBGHZ_Init(void)
{

  /* USER CODE BEGIN SUBGHZ_Init 0 */

  /* USER CODE END SUBGHZ_Init 0 */

  /* USER CODE BEGIN SUBGHZ_Init 1 */

  /* USER CODE END SUBGHZ_Init 1 */
  hsubghz.Init.BaudratePrescaler = SUBGHZSPI_BAUDRATEPRESCALER_8;
  if (HAL_SUBGHZ_Init(&hsubghz) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SUBGHZ_Init 2 */

  /* USER CODE END SUBGHZ_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  LL_USART_InitTypeDef USART_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clocks
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInitStruct.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Peripheral clock enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);

  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);
  /**USART1 GPIO Configuration
  PB7   ------> USART1_RX
  PB6   ------> USART1_TX
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_7|LL_GPIO_PIN_6;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_7;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USART1 interrupt Init */
  NVIC_SetPriority(USART1_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),5, 0));
  NVIC_EnableIRQ(USART1_IRQn);

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  USART_InitStruct.PrescalerValue = LL_USART_PRESCALER_DIV1;
  USART_InitStruct.BaudRate = 9600;
  USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
  USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
  USART_InitStruct.Parity = LL_USART_PARITY_NONE;
  USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
  USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
  USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
  LL_USART_Init(USART1, &USART_InitStruct);
  LL_USART_SetTXFIFOThreshold(USART1, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_SetRXFIFOThreshold(USART1, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_DisableFIFO(USART1);
  LL_USART_ConfigAsyncMode(USART1);

  /* USER CODE BEGIN WKUPType USART1 */

  /* USER CODE END WKUPType USART1 */

  LL_USART_Enable(USART1);

  /* Polling USART1 initialisation */
  while((!(LL_USART_IsActiveFlag_TEACK(USART1))) || (!(LL_USART_IsActiveFlag_REACK(USART1))))
  {
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LED1_Pin|LED2_Pin|LED3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, FE_CTRL3_Pin|FE_CTRL2_Pin|FE_CTRL1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED1_Pin LED2_Pin LED3_Pin */
  GPIO_InitStruct.Pin = LED1_Pin|LED2_Pin|LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : ChanA_encoder_Pin Compass_Pin */
  GPIO_InitStruct.Pin = ChanA_encoder_Pin|Compass_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Button_Pin */
  GPIO_InitStruct.Pin = Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Button_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : FE_CTRL3_Pin FE_CTRL2_Pin FE_CTRL1_Pin */
  GPIO_InitStruct.Pin = FE_CTRL3_Pin|FE_CTRL2_Pin|FE_CTRL1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : Estop_Pin */
  GPIO_InitStruct.Pin = Estop_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Estop_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ChanB_Encoder_Pin */
  GPIO_InitStruct.Pin = ChanB_Encoder_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ChanB_Encoder_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Freq_id_Pin */
  GPIO_InitStruct.Pin = Freq_id_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Freq_id_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle)
{
//	if ( *UartHandle == huart2){
		int test =1;

}

void GPIOcallback(uint16_t Pin){
	gpioGsEnum_e action = gpioGsFSM(Pin);
	switch(action){
	  case CwTurn:
	  // Handle clockwise turn
			//HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, 1);
		    voltageIndex = (voltageIndex + 1) % arraySize;
		    //osDelay(1);
			//HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, 0);
			break;

	  case CCwTurn:
	  // Handle counterclockwise turn
		    voltageIndex = (voltageIndex -1 + arraySize)% arraySize;
			//HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, 1);
			//osDelay(1);
			//HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, 0);
			break;
	  case enter:
	  // Handle encoder button press
			selectedVoltage = voltageIndex;
			//state = s3;
			break;
	  case Estop:
	  // Handle emergency stop
		  if(state ==s3){
				//HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, 1);
			  for(int i=0; i<=3; i++){
				  arm();
			  }
				state = s4;
		  }
			break;
	  default:
	  // No action detected
	  break;
	  }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	GPIOcallback(GPIO_Pin);
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* init code for SubGHz_Phy */
  MX_SubGHz_Phy_Init();
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
//	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) == GPIO_PIN_RESET)
//	{
//		osDelay(20); //Debounce button
//		if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) == GPIO_PIN_RESET)
//		{
//			arm();
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
//		}
//	}
//	//HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_9);
//    osDelay(500);
//    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);
    osDelay(1);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_getBLE_Data */
/**
* @brief Function implementing the myTask02 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_getBLE_Data */
void getBLE_Data(void *argument)
{
  /* USER CODE BEGIN getBLE_Data */
  /* Infinite loop */
  for(;;)
  {
//	  getBLE();
//	  if () == GPIO_PIN_RESET)
//	  {
//	  	osDelay(20); //Debounce button
//	  	if (HAL_GPIO_ReadPin(LED2_GPIO_Port, LED2_Pin) == GPIO_PIN_RESET)
//	  	{
//	  		arm();
//	  		//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
//	  	}
//	  }
	  //HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_9);
	  //osDelay(500);
	  //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);
	  //osDelay(1);


  }
  /* USER CODE END getBLE_Data */
}

/* USER CODE BEGIN Header_StartBlink */
/**
* @brief Function implementing the blink01 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartBlink */
void StartBlink(void *argument)
{
  /* USER CODE BEGIN StartBlink */
  /* Infinite loop */
  for(;;)
  {
	//HAL_GPIO_TogglePin (GPIOB, GPIO_PIN_15);
    //osDelay(500);
  }
  /* USER CODE END StartBlink */
}

/* USER CODE BEGIN Header_Handshake_entry */
/**
* @brief Function implementing the Handshake thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Handshake_entry */
void Handshake_entry(void *argument)
{
  /* USER CODE BEGIN Handshake_entry */
	  /* Infinite loop */
		for(;;){
			if (state == s1){
				int voltageIndex = 0;
				globPinState = none;
				GPIOcallback(none);
				lora_msg_s msgRx;
				//send out message to OB
				hs();
				osMessageQueueGet(messageQueueHandle,&msgRx,0,0);
				if(msgRx.msg_id == ns_ack)
				  {
					ns();
					state = s2;
					//vTaskSuspend(HandshakeHandle);
					osDelay(3000);
				  }
			}
		}
		osDelay(1);
  /* USER CODE END Handshake_entry */
}

/* USER CODE BEGIN Header_Freq_check_s2 */
/**
* @brief Function implementing the Freq_check thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Freq_check_s2 */
void Freq_check_s2(void *argument)
{

  /* USER CODE BEGIN Freq_check_s2 */
	for(;;){
		if (state == s2){
			//display the following
			ssd1306_Fill(Black);
			ssd1306_SetCursor(5,5);
			ssd1306_WriteString("Frequency Selection", Font_6x8 ,White);
			ssd1306_SetCursor(5,25);
			lowFreq = ssd1306_WriteString("438MHz", Font_6x8 ,White);
			ssd1306_SetCursor(5,45);
			highFreq = ssd1306_WriteString("915MHz", Font_6x8 ,White);
			ssd1306_UpdateScreen();
			osDelay(3000);
			//checks which board it is
			if (HAL_GPIO_ReadPin(Freq_id_GPIO_Port, Freq_id_Pin)== 1){
				ssd1306_SetCursor(5,45);
				highFreq= ssd1306_WriteString("915MHz Selected", Font_6x8 ,Black);
				ssd1306_UpdateScreen();
				osDelay(2000);
			}
			//if counter is going CCW, highlight the lowFreq string
			else{
				ssd1306_SetCursor(5,25);
				lowFreq = ssd1306_WriteString("438MHz Selected", Font_6x8 ,Black);
				ssd1306_UpdateScreen();
				osDelay(2000);
			}
			ssd1306_Fill(Black);
			uint8_t test = 0;

			while(selectedVoltage == -1){
				globPinState = none;
//				osDelay(50);
				ssd1306_SetCursor(5,5);
				GPIOcallback(globPinState);
				test = voltages[voltageIndex];
				snprintf(buffer, sizeof(buffer), "Select [%ds]", voltageIndex+2);
				ssd1306_WriteString(buffer, Font_6x8 ,White);
				ssd1306_UpdateScreen();
			}
			test = voltages[selectedVoltage];
			ssd1306_Fill(Black);
			ssd1306_SetCursor(5,5);
			snprintf(buffer, sizeof(buffer), "Selected [%ds]", voltageIndex+2);
			batteryInstance.config = voltageIndex+2;
			ssd1306_WriteString(buffer, Font_6x8 ,White);
			ssd1306_UpdateScreen();
			osDelay(3000);
			state = s3;
		}
		osDelay(10);

	}
  /* USER CODE END Freq_check_s2 */
}

/* USER CODE BEGIN Header_HeartBeat_s3 */
/**
* @brief Function implementing the HeartBeat thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_HeartBeat_s3 */
void HeartBeat_s3(void *argument)
{
  /* USER CODE BEGIN HeartBeat_s3 */
  /* Infinite loop */
  for(;;)
  {
	  if(state == s3){
		  globPinState = none;
		  GPIOcallback(globPinState);
		  lora_msg_s msgRx;
			//Get battery voltage reading
			getBatVolt(&batteryInstance);
			char buf[20];
			//Using snprintf because its **memory safe**
			send_GS_heartbeat();
			int16_t recieved_RSSI;
			osMessageQueueGet(signalHandle,&recieved_RSSI,0,0);
			osMessageQueueGet(messageQueueHandle,&msgRx,0,0);
			snprintf(buf, sizeof(buf), "OB Battery: %d%%",msgRx.b_percentage);
			ssd1306_Fill(Black);
			ssd1306_SetCursor(5,5);
			ssd1306_WriteString(buf, Font_6x8 ,White);
			snprintf(buf, sizeof(buf), "GS Battery: %d%%",batteryInstance.percent);
			ssd1306_SetCursor(5,15);
			ssd1306_WriteString(buf, Font_6x8 ,White);
			if(msgRx.msg_id == Heartbeat)
			  {
				char buffer1[100];
				//int32_t lon= msgRx.gps_long;
				//int32_t lat = msgRx.gps_lat;
				snprintf(buffer1, sizeof(buffer1), "Long: %ld", msgRx.gps_long);
				//NEW CODE SINCE PREVIOUS PDR
				//ssd1306_Init();
				ssd1306_SetCursor(5,25);
				ssd1306_WriteString(buffer1, Font_6x8 ,White);
				snprintf(buffer1, sizeof(buffer1), "Lat: %ld", msgRx.gps_lat);
				ssd1306_SetCursor(5,35);
				ssd1306_WriteString(buffer1, Font_6x8 ,White);
				char RSSI_buf[20];
				snprintf(RSSI_buf, sizeof(RSSI_buf), "RSSI %d dBm", recieved_RSSI);
				ssd1306_SetCursor(5,45);
				ssd1306_WriteString(RSSI_buf, Font_6x8 ,White);
				ssd1306_UpdateScreen();
				//vTaskSuspend(HandshakeHandle);
				//osDelay(3000);
			  }
			//ssd1306_UpdateScreen();
		}

		  osDelay(1);
  }
  /* USER CODE END HeartBeat_s3 */
}

/* USER CODE BEGIN Header_CompassData */
/**
* @brief Function implementing the Compass thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_CompassData */
void CompassData(void *argument)
{
  /* USER CODE BEGIN CompassData */
  /* Infinite loop */
  for(;;)
  {
	  if(state == s4){//state ==s4
		  lora_msg_s gps_data;
		  lora_msg_s msgRxS4;
		  osMessageQueueGet(messageQueueHandle,&msgRxS4,0,0);
			  send_GS_heartbeat();
			  getGPS(&gps_data);
	  		  osMessageQueueGet(messageQueueHandle,&msgRxS4,0,0);
	  		  double GS_Lat = ((double)gps_data.gps_lat)/10000000;
	  		  double GS_Long = ((double)gps_data.gps_long)/10000000;
	  		  double OB_Lat = ((double)msgRxS4.gps_lat)/10000000;
	  		  double OB_Long = ((double)msgRxS4.gps_long)/10000000;
	    	  double bearing = getBearing(GS_Lat, GS_Long, OB_Lat, OB_Long);
	    	  double range = getRange(GS_Lat, GS_Long, OB_Lat, OB_Long);
//			  double MS_lat = 29.581601912999098;
//			  double MS_long = -98.61647540290765;
//			  double Austin_lat = 30.2672;
//			  double Austin_long = -97.7431;
//			  double north_lat = 29.622449803201366;
//			  double north_long = -98.61836061258202;
//
//
//			  double test_bearing = getBearing(MS_lat, MS_long, north_lat, north_long);
			  display_arrow(bearing, range);




	  //		  ssd1306_Fill(Black);
	  //		  ssd1306_SetCursor(5,5);
	  //		  ssd1306_WriteString("Stage 4 ;P", Font_6x8 ,White);
	  //		  ssd1306_UpdateScreen();
			  if (msgRxS4.msg_id == recover){
				  	  	  ssd1306_Fill(Black);
				  	  	  //init();
			  			  state = s1;
			  			  osDelay(3000);
			  		  }

		  }



	  }

    osDelay(1);
  }
  /* USER CODE END CompassData */

void enableCheck(){
		  ssd1306_Fill(Black);
		  ssd1306_SetCursor(2,45);
		  ssd1306_WriteString("Enable off", Font_6x8 ,White);
		  ssd1306_UpdateScreen();
}
/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
