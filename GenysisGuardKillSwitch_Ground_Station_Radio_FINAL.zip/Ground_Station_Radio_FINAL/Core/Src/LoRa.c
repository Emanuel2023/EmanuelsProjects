/*
 * LoRa.c
 *
 *  Created on: Mar 6, 2024
 *      Author: super
 */

#include "LoRa.h"
#include "Radio.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "subghz_phy_app.h"
#include "M10S.h"
#include <string.h>
#include <math.h>
#include "iis2mdc_polling_data.h"

extern uint8_t M10S_received_buffer_RX[36];
extern uint8_t M10S_RX_complete_flag;
extern iis2mdc_data_t compData;
extern stmdev_ctx_t compass1;
extern uint8_t state;
//PV
const uint8_t logo[] = {
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x78, 0x0E,
		0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x80, 0xC0, 0xE0, 0xF0, 0x70, 0x38, 0x1C, 0x0C, 0x00, 0xF0, 0x07, 0x80, 0x80, 0x80, 0x0F, 0xF0,
		0x00, 0x0C, 0x1C, 0x38, 0x70, 0xF0, 0xE0, 0xC0, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x60, 0x70, 0x38, 0x1C, 0x1E, 0x0F, 0x07, 0x07,
		0x09, 0x12, 0x22, 0xFC, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE, 0xFC,
		0x22, 0x12, 0x09, 0x07, 0x07, 0x0F, 0x1E, 0x1C, 0x38, 0x70, 0xE0, 0x40, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x40, 0xC0, 0xC0, 0x80, 0x00, 0x00, 0x00, 0x80, 0x40, 0x20, 0x10, 0x98,
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x98, 0x10, 0x20,
		0x40, 0x80, 0x00, 0x00, 0x00, 0x80, 0xC0, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x80, 0x40, 0x20, 0x11, 0x0B, 0x0F, 0x0F, 0x3F, 0x7C, 0xFC, 0xF2, 0xC9, 0x88, 0x84, 0x87, 0x4F,
		0x5F, 0x7F, 0x3F, 0x3F, 0x3F, 0x7F, 0x5F, 0x4F, 0x87, 0x84, 0x89, 0xCB, 0xF6, 0xFC, 0x7C, 0x3F,
		0x0F, 0x0F, 0x1B, 0x31, 0x60, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x18, 0x1C, 0x06, 0x0B, 0x09, 0x08, 0x04,
		0x04, 0x04, 0x02, 0x02, 0x02, 0x00, 0x01, 0x01, 0x01, 0x03, 0x07, 0x0E, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x04, 0x0E, 0x07, 0x03, 0x01, 0x01, 0x01, 0x00, 0x02, 0x02, 0x00, 0x04,
		0x04, 0x04, 0x08, 0x09, 0x0A, 0x14, 0x18, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x38, 0x7C,
		0xFE, 0xFE, 0xEE, 0xCA, 0xD2, 0x9C, 0x00, 0x00, 0xFE, 0x02, 0xFE, 0xE0, 0xF0, 0xFC, 0x3E, 0x0E,
		0x06, 0x00, 0x02, 0x0E, 0x1E, 0x7E, 0xF8, 0xF0, 0xD8, 0x66, 0x1A, 0x0E, 0x06, 0x00, 0xFE, 0x06,
		0xF6, 0xFE, 0xFC, 0xF0, 0xC0, 0xC0, 0xFE, 0x06, 0xFE, 0x00, 0xFE, 0x06, 0xFE, 0xEE, 0xEE, 0xEE,
		0xEE, 0xCE, 0x04, 0x0E, 0x0E, 0xFE, 0xFE, 0xFE, 0xFE, 0x0E, 0x0E, 0x06, 0x0E, 0x1A, 0x16, 0x1D,
		0x1F, 0x1F, 0x0F, 0x03, 0x00, 0x1F, 0x18, 0x1F, 0x01, 0x03, 0x07, 0x1F, 0x1E, 0x1C, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x1F, 0x1F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x18, 0x1F, 0x0F, 0x00,
		0x03, 0x07, 0x1F, 0x1B, 0x18, 0x1F, 0x00, 0x1F, 0x18, 0x1F, 0x1F, 0x1C, 0x1C, 0x1C, 0x1C, 0x00,
		0x00, 0x00, 0x0F, 0x1F, 0x1F, 0x0F, 0x00, 0x00
};



// Function to draw the logo on the screen
void drawImage(uint8_t *image, uint8_t width, uint8_t height) {
    for (uint8_t y = 0; y < height / 8; y++) {
        for (uint8_t x = 0; x < width; x++) {
            uint8_t byte = image[y * width + x];
            for (uint8_t bit = 0; bit < 8; bit++) {
                if (byte & (1 << bit)) {
                    ssd1306_DrawPixel(x, y * 8 + bit, White);
                } else {
                    ssd1306_DrawPixel(x, y * 8 + bit, Black);
                }
            }
        }
    }
  ssd1306_SetCursor(68,5);
  ssd1306_WriteString("Welcome to", Font_6x8 ,White);
  ssd1306_SetCursor(68,25);
  ssd1306_WriteString("Genysis", Font_6x8 ,White);
  ssd1306_SetCursor(68,45);
  ssd1306_WriteString("Guard", Font_6x8 ,White);
  ssd1306_UpdateScreen();
}
void init(){

	SubghzApp_Init();
}

//Function to handle incoming heartbeat message from onboard
void receive_heartBeat(){
	HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_15);
}

void freqCheck(){


}

void hs(){
	lora_msg_s init_comm;
	init_comm.ID = On_Board;
	init_comm.msg_id = HS;
	init_comm.state = s1;
	init_comm.gps_long=0;
	init_comm.gps_lat=0;

	//Serialize data in Kill_Command to be sent over
	radio_status_t status = Radio.Send((uint8_t*)&init_comm, sizeof(init_comm));

	//Call
	drawImage(logo, 61, 64);

}
void ns(){
	lora_msg_s next_state;
	next_state.ID = On_Board;
	next_state.msg_id = HS;
	next_state.state = s2;
	next_state.gps_long=0;
	next_state.gps_lat=0;

	//Serialize data in Kill_Command to be sent over
	radio_status_t status = Radio.Send((uint8_t*)&next_state, sizeof(next_state));

}
//COMPLETELY MODIFED/ORIGINAL
void arm(){

	//Define Variables
	lora_msg_s Kill_Command;
	Kill_Command.ID = On_Board;
	Kill_Command.msg_id = Arm;
	Kill_Command.gps_long=0;
	Kill_Command.gps_lat=0;
//	uint8_t buffer [sizeof(Kill_Command)];
//
//	//Serialize data in Kill_Command to be sent over
//	memcpy(buffer, &Kill_Command, sizeof(Kill_Command));
//
//	//Send kill command
//	Radio.Send(buffer, sizeof(buffer));

	radio_status_t status = Radio.Send((uint8_t*)&Kill_Command, sizeof(Kill_Command));
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);

	//uint8_t Kill_Command[] = "Activate Killswitch";

	char buffer1[100];
	sprintf(buffer1, "Long: %lu", Kill_Command.gps_long);

	//NEW CODE SINCE PREVIOUS PDR
//	ssd1306_Init();
//	ssd1306_SetCursor(5,5);
//	ssd1306_WriteString(buffer1, Font_6x8 ,White);
//	ssd1306_UpdateScreen();
//	sprintf(buffer1, "Lat: %lu", Kill_Command.gps_lat);
//	ssd1306_SetCursor(5,25);
//	ssd1306_WriteString(buffer1, Font_6x8 ,White);
//	ssd1306_UpdateScreen();

}

double getRange(double lat1, double lon1, double lat2, double lon2){
    //Determine range from GS to OB
    double lat1_rad = (lat1* M_PI)/180.0;
    double lon1_rad = (lon1* M_PI)/180.0;
    double lat2_rad = (lat2* M_PI)/180.0;
    double lon2_rad = (lon2* M_PI)/180.0;
    double radius = 6371000.0;


    double delta_long = lon2_rad - lon1_rad;
    double delta_lat = lat2_rad - lat1_rad;
    double a =(sin(delta_lat/2)*sin(delta_lat/2))+(cos(lat1_rad)*cos(lat2_rad))*(sin(delta_long/2))*sin(delta_long/2);
    double c = 2*atan2(sqrt(a), sqrt((1-a)));
    double d = c*radius;



    return d;
}

double getBearing(double lat1, double lon1, double lat2, double lon2){

	//Determine bearing from GS to OB
	double lat1_rad = (lat1* M_PI)/180.0;
	double lon1_rad = (lon1* M_PI)/180.0;
	double lat2_rad = (lat2* M_PI)/180.0;
	double lon2_rad = (lon2* M_PI)/180.0;

	double delta_long = lon2_rad - lon1_rad;
	double x = cos(lat1_rad)*sin(lat2_rad)-sin(lat1_rad)*cos(lat2_rad)*cos(delta_long);
	double y = sin(delta_long)*cos(lat2_rad);
	double bearing = (atan2(y,x))*(180/M_PI);

	//Determine compass heading
	//Sensitivity parameter: 1.5 mG/LSB
	compData = iis2mdc_read_data(&compass1);
	// maybe add a delay?
	// osDelay(10);

//	double compass_X = compData.magnetX * 1.5;
//	double compass_Y = compData.magnetY * 1.5;
	double compX = (double)compData.magnetX;
	double compY = (double)compData.magnetY;
	double gs_heading = (atan2(compY,-compX))*(180/M_PI);


	//Subtract two bearings and 90 offset to get bearing to display
	double arrow_direction = bearing -gs_heading;

	//testing
	//double arrow_direction = gs_heading;
	if (arrow_direction < 0)
		arrow_direction = arrow_direction + 360.0;

	return arrow_direction;
}

void display_arrow(double arrow_Direction, double ob_range)
{
	SSD1306_VERTEX arrow[] = {{64, 30}, {50, 40}, {64, 20}, {78, 40}, {64, 30}};
	SSD1306_VERTEX rotated_arrow[5];
	float radians = arrow_Direction * (M_PI/180.0);
	int16_t x_center = 64;
	int16_t y_center = 32;

	//Rotate arrow
	for (int i = 0; i < 5; ++i){
		double rotated_x = (arrow[i].x - x_center)* cos(radians)- (arrow[i].y - y_center) * sin(radians) + x_center;
		double rotated_y = (arrow[i].x - x_center)* sin(radians)+ (arrow[i].y - y_center) * cos(radians) + y_center;

		//Center arrow and cast into uint8_t
		rotated_arrow[i].x = (uint8_t)(rotated_x);
		rotated_arrow[i].y = (uint8_t)(rotated_y);
	}

	ssd1306_Fill(Black);
	ssd1306_Polyline(rotated_arrow, 5, White);

    char Range_buf[20];
	snprintf(Range_buf, sizeof(Range_buf), "Range %f m", ob_range);
	ssd1306_SetCursor(5,55);
	ssd1306_WriteString(Range_buf, Font_6x8 ,White);
	ssd1306_UpdateScreen();

}

void reset(){


}


void getGPS(lora_msg_s *inst){

	if (M10S_RX_complete_flag == 1)
	{
		M10S_RX_complete_flag = 0;
		if (M10S_UBX_CHKSUM_Check(&M10S_received_buffer_RX[0],36) == 1)
		{
			M10S_UBX_NAV_POSLLH_Parsing(&M10S_received_buffer_RX[0], &posllh_structure_variable);
			inst -> gps_lat = posllh_structure_variable.latitude;
			inst -> gps_long= posllh_structure_variable.longitude;

//			printf("Latitude: %ld\t     Longitude: %ld\t\n\r", posllh_structure_variable.latitude, posllh_structure_variable.longitude);
    		printf("GLatitude: %ld\t     GLongitude: %ld\t\n\r", inst -> gps_lat, inst -> gps_long);
		}
	}
}

void getBLE(){

}
//Function to send heartbeat to onboard
//If on board misses X number of these message, termination will automatically be triggered
void send_GS_heartbeat(){
	lora_msg_s gs_heartbeat;
	gs_heartbeat.ID = On_Board;
	gs_heartbeat.msg_id = Heartbeat;
	gs_heartbeat.gps_long=0;
	gs_heartbeat.gps_lat=0;
	gs_heartbeat.state=s3;
	if(state ==s4){
		gs_heartbeat.state=s4;
	}

	Radio.Send((uint8_t*)&gs_heartbeat, sizeof(gs_heartbeat));

}

//Input parameters not needed if using a message queue
void processData(){
	lora_msg_s in;
	lora_msg_s out;

	osMessageQueueGet(messageQueueHandle, &in, 0, osWaitForever);

	switch(in.msg_id){
	case Init:
		init();
		break;
	case Heartbeat:
		receive_heartBeat();
		break;
	case HS:
		hs();
		break;
	case ns_ack:
		ns();
		break;
	case Arm:
		arm();
		break;
	case Reset:
		reset();
		break;
	}
}


