/*
 * M10S.c
 *
 *  Created on: Aug 22, 2019
 *      Author: Administrator
 */

#include "M10S.h"

M10S_UBX_NAV_POSLLH posllh_structure_variable;

const unsigned char UBX_CFG_PRT[] = {
	0xB5, 0x62, 0x06, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00,
	0xD0, 0x08, 0x00, 0x00, 0x80, 0x25, 0x00, 0x00, 0x01, 0x00,
	0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9A, 0x79
};

const unsigned char UBX_CFG_MSG[] = {
	0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0x01, 0x02, 0x00, 0x01,
	0x00, 0x00, 0x00, 0x00, 0x13, 0xBE
};

const unsigned char UBX_CFG_RATE[] = {
	0xB5, 0x62, 0x06, 0x08, 0x06, 0x00, 0x10, 0x27, 0x01, 0x00,
	0x01, 0x00, 0x4D, 0xDD
};

const unsigned char UBX_CFG_CFG[] = {
	0xB5, 0x62, 0x06, 0x09, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x00,
	0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x31,
	0xBF
};

void M10S_TransmitData(unsigned char* UBX_data, unsigned char UBX_message_length)
{
	int i = 0;
	if (UBX_message_length > 0)
	{
		do
		{
			while(!LL_USART_IsActiveFlag_TXE(USART1));
			LL_USART_TransmitData8(USART1, *(UBX_data+i));
			i++;
		}while (i < UBX_message_length);
	}
}

void M10S_USART1_Initialization(void)
{
    LL_USART_InitTypeDef USART_InitStruct = {0};
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* Peripheral clock enable */
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);

    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);

    /**USART1 GPIO Configuration
    PB7   ------> USART1_RX
    PB6   ------> USART1_TX
    */
    GPIO_InitStruct.Pin = LL_GPIO_PIN_7 | LL_GPIO_PIN_6;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
    GPIO_InitStruct.Alternate = LL_GPIO_AF_7;
    LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    NVIC_SetPriority(USART1_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0, 0));
    NVIC_EnableIRQ(USART1_IRQn);

    USART_InitStruct.BaudRate = 9600;
    USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
    USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
    USART_InitStruct.Parity = LL_USART_PARITY_NONE;
    USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
    USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
    LL_USART_Init(USART1, &USART_InitStruct);
    LL_USART_ConfigAsyncMode(USART1);
    LL_USART_Enable(USART1);
}


void M10S_Initialization(void)
{
	M10S_USART1_Initialization();

	M10S_TransmitData(&UBX_CFG_PRT[0], sizeof(UBX_CFG_PRT));
	HAL_Delay(100);
	M10S_TransmitData(&UBX_CFG_MSG[0], sizeof(UBX_CFG_MSG));
	HAL_Delay(100);
	M10S_TransmitData(&UBX_CFG_RATE[0], sizeof(UBX_CFG_RATE));
	HAL_Delay(100);
	M10S_TransmitData(&UBX_CFG_CFG[0], sizeof(UBX_CFG_CFG));
}





unsigned char M10S_UBX_CHKSUM_Check(unsigned char* UBX_data, unsigned char UBX_message_length)
{
	unsigned char CK_A = 0, CK_B = 0;

	for(int i = 2; i < UBX_message_length - 2; i++)
	{
		CK_A = CK_A + UBX_data[i];
		CK_B = CK_B + CK_A;
	}

	return ((CK_A == UBX_data[UBX_message_length - 2]) && (CK_B == UBX_data[UBX_message_length - 1]));
}

void M10S_UBX_NAV_POSLLH_Parsing(unsigned char* UBX_data, M10S_UBX_NAV_POSLLH* posllh_structure_variable)
{
	posllh_structure_variable->CLASS = UBX_data[2];
	posllh_structure_variable->ID = UBX_data[3];
	posllh_structure_variable->length = UBX_data[4] | UBX_data[5] << 8;

	posllh_structure_variable->iTOW = UBX_data[6] | UBX_data[7] << 8 | UBX_data[8] << 16 | UBX_data[9] << 24;
	posllh_structure_variable->longitude = UBX_data[10] | UBX_data[11] << 8 | UBX_data[12] << 16 | UBX_data[13] << 24;
	posllh_structure_variable->latitude = UBX_data[14] | UBX_data[15] << 8 | UBX_data[16] << 16 | UBX_data[17] << 24;
	posllh_structure_variable->altitude = UBX_data[18] | UBX_data[19] << 8 | UBX_data[20] << 16 | UBX_data[21] << 24;
	posllh_structure_variable->hMSL = UBX_data[22] | UBX_data[23] << 8 | UBX_data[24] << 16 | UBX_data[25] << 24;
	posllh_structure_variable->hAcc = UBX_data[26] | UBX_data[27] << 8 | UBX_data[28] << 16 | UBX_data[29] << 24;
	posllh_structure_variable->vAcc = UBX_data[30] | UBX_data[31] << 8 | UBX_data[32] << 16 | UBX_data[33] << 24;
	//posllh_structure->longitude_f64 = posllh_structure->longitude / 10000000
	//posllh_structure->latitude_f64 = posllh_structure->latitude / 10000000
}
