/*
 ******************************************************************************
 * @file    		iis2mdc_polling_data.c
 * @author  		Sensors Software Solution Team
 * @modified by		Dalen Ricks
 * @date			October 24, 2024
 * @brief   		This file show how to get data from sensor in polling mode.
 *
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 *
 *	Notes from Dalen:
 *		This was originally an example created by the ST team, but I modified
 *		it to quickly integrate the compass into the Genysis Guard system. The
 *		link to the original example is below:
 *
 *		https://github.com/STMicroelectronics/STMems_Standard_C_drivers/blob/master/iis2mdc_STdC/examples/iis2mdc_read_data_polling.c
 *
 *		Any functions that have the "platform" prefix are from the original example
 */

/* Includes ------------------------------------------------------------------*/
#include "iis2mdc_polling_data.h"

/* Extern variables */
extern I2C_HandleTypeDef hi2c1;	/*MUST BE CHANGED IF NEW I2C IS USED*/
int maxX;
int minX;
int maxY;
int minY;
int offset_x;
int offset_y;


/**
  * @brief	Initializes the compass data structure
  *
  * @notes	The function assigns compass data structure from the
  * 		low level iis2mdc.h file and initializes the compass
  *			by calling a hand-full of functions. The handle is
  *			assigned from the extern i2c handle and must be changed
  *			if a new i2c is used.
  *
  * @param	*dev_ctx:	The data structure associated with the
  * 					compass instance.
  *
  *	@retval	void
  */
iis2mdc_status_e iis2mdcInit(stmdev_ctx_t *dev_ctx){
	/* Initialize mems driver interface */
	uint8_t whoamI, rst;

	dev_ctx -> write_reg = platform_write;
	dev_ctx -> read_reg = platform_read;
	dev_ctx -> mdelay = platform_delay;
	dev_ctx -> handle = &hi2c1;

	/* Wait sensor boot time */
	platform_delay(BOOT_TIME);

	/* Check device ID */
	whoamI = 0;
	iis2mdc_device_id_get((stmdev_ctx_t *) dev_ctx, &whoamI);

	if ( whoamI != IIS2MDC_ID )
		return IIS2MDC_ERROR; /*manage here device not found */

	/* Restore default configuration */
	iis2mdc_reset_set((stmdev_ctx_t *) dev_ctx, PROPERTY_ENABLE);

	do {
	iis2mdc_reset_get((stmdev_ctx_t *) dev_ctx, &rst);
	} while (rst);

	/* Enable Block Data Update */
	iis2mdc_block_data_update_set((stmdev_ctx_t *) dev_ctx, PROPERTY_ENABLE);

	/* Set Output Data Rate */
	iis2mdc_data_rate_set((stmdev_ctx_t *) dev_ctx, IIS2MDC_ODR_10Hz);

	/* Set / Reset sensor mode */
	iis2mdc_set_rst_mode_set((stmdev_ctx_t *) dev_ctx, IIS2MDC_SENS_OFF_CANC_EVERY_ODR);

	/* Enable temperature compensation */
	iis2mdc_offset_temp_comp_set((stmdev_ctx_t *) dev_ctx, PROPERTY_ENABLE);

	/* Set device in continuous mode */
	iis2mdc_operating_mode_set((stmdev_ctx_t *) dev_ctx, IIS2MDC_CONTINUOUS_MODE);
	return IIS2MDC_OK;
}

/**
  * @brief	Retrieves compensated data from the compass
  *
  * @notes	This function takes in the compass instance data
  * 		structure and outputs a data structure that contains
  * 		all of the compass X, Y, Z, and temperature data
  *
  * 		Ensure delay is long enough to allow compass time to
  * 		generate new data. Otherwise the function will return
  * 		the junk data (I think its the pointer address)
  *
  * @param	*dev_ctx:	The data structure associated with the
  * 					compass instance.
  *
  *	@retval	iis2mdc_data_t
  */
iis2mdc_data_t iis2mdc_read_data(stmdev_ctx_t *dev_ctx)
{
	iis2mdc_data_t data;

	data.magnetX = 0.0;
	data.magnetY = 0.0;
	data.magnetZ = 0.0;
	data.temp = 0;

	int16_t data_raw_temperature;
	int16_t data_raw_magnetic[3] = {0};

    /* Read output only if new value is available */
    iis2mdc_mag_data_ready_get((stmdev_ctx_t *) dev_ctx, &data.data_ready);

    if (data.data_ready) {
      /* Read magnetic field data */
      memset(data_raw_magnetic, 0x00, 3 * sizeof(int16_t));
      iis2mdc_magnetic_raw_get((stmdev_ctx_t *) dev_ctx, data_raw_magnetic);
      offset_x = (220 + (-399))/2;
      offset_y = (300 + (-244))/2;
//	  offset_x = (maxX+minX)/2;
//	  offset_y = (maxY+minY)/2;
//	  offset_z = (maxZ-minZ)/2;
//
//	  avg_delta= (offset_x + offset_y + offset_z)/3;
//
//	  scale_x=avg_delta / offset_x;
//	  scale_y=avg_delta / offset_y;
//	  scale_z=avg_delta / offset_z;

      data.magnetX = iis2mdc_from_lsb_to_mgauss( data_raw_magnetic[0])-offset_x ;
      data.magnetY = iis2mdc_from_lsb_to_mgauss( data_raw_magnetic[1])-offset_y;
      data.magnetZ = iis2mdc_from_lsb_to_mgauss( data_raw_magnetic[2]);

//      if(data.magnetX>maxX)
//    	  maxX=data.magnetX;
//      if(data.magnetX<minX)
//    	  minX=data.magnetX;
//      if(data.magnetY>maxY)
//		  maxY=data.magnetY;
//	  if(data.magnetY<minY)
//		  minY=data.magnetY;


      /* Read temperature data */
      memset( &data_raw_temperature, 0x00, sizeof(int16_t) );
      iis2mdc_temperature_raw_get((stmdev_ctx_t *) dev_ctx, &data_raw_temperature);
      data.temp = iis2mdc_from_lsb_to_celsius (data_raw_temperature);
    }
    return data;
}

/*
 * @brief  Write generic device register (platform dependent)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to write
 * @param  bufp      pointer to data to write in register reg
 * @param  len       number of consecutive register to write
 *
 */
int32_t platform_write(void *handle, uint8_t reg, const uint8_t *bufp,
                              uint16_t len)
{
	HAL_I2C_Mem_Write(handle, IIS2MDC_I2C_ADD, reg, I2C_MEMADD_SIZE_8BIT, (uint8_t*) bufp, len, 1000);
	return 0;
}

/*
 * @brief  Read generic device register (platform dependent)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to read
 * @param  bufp      pointer to buffer that store the data read
 * @param  len       number of consecutive register to read
 *
 */
int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len)
{
	HAL_I2C_Mem_Read(handle, IIS2MDC_I2C_ADD, reg, I2C_MEMADD_SIZE_8BIT, bufp, len, 1000);
	return 0;
}

/*
 * @brief  platform specific delay (platform dependent)
 *
 * @param  ms        delay in ms
 *
 */
void platform_delay(uint32_t ms)
{
  HAL_Delay(ms);
}

