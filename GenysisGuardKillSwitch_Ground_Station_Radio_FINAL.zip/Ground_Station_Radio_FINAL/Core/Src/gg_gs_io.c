/*
 * gg_gs_io.c
 *
 *  Created on: Sep 11, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 */

#include "gg_gs_io.h"
#include <string.h>
#include "ssd1306.h"
#include "ssd1306_fonts.h"


gsIO_s encChanA;
gsIO_s encChanB;
gsIO_s encChanBtn;
gsIO_s eStop;

/*
 * @brief 	Function to initialize the Encoder Channel A.
 *
 * @note 	This channel is typically the "CLK" pin, and is triggered by an interrupt.
 *
 * @param	GPIOx:	The port of the channel that the encoder channel is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the encoder channel is attached to
 *
 * @retval	none
 */
void encChanAInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	encChanA.GPIOx = GPIOx;
	encChanA.GPIO_Pin = GPIO_Pin;
}


/*
 * @brief 	Function to initialize the Encoder Channel B.
 *
 * @note 	This channel is typically the "Data" pin.
 *
 * @param	GPIOx:	The port of the channel that the encoder channel is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the encoder channel is attached to
 *
 * @retval	none
 */
void encChanBInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	encChanB.GPIOx = GPIOx;
	encChanB.GPIO_Pin = GPIO_Pin;
}


/*
 * @brief 	Function to initialize the Encoder Button.
 *
 * @note 	This channel is typically the "Btn" pin, and is triggered by an interrupt.
 *
 * @param	GPIOx:	The port of the channel that the encoder button is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the encoder button is attached to
 *
 * @retval	none
 */
void encChanBtnInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	encChanBtn.GPIOx = GPIOx;
	encChanBtn.GPIO_Pin = GPIO_Pin;
}


/*
 * @brief 	Function to initialize the Emergency Stop Button.
 *
 * @note 	This channel is triggered by an interrupt.
 *
 * @param	GPIOx:	The port of the channel that the encoder channel is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the encoder channel is attached to
 *
 * @retval	none
 */
void eStopInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	eStop.GPIOx = GPIOx;
	eStop.GPIO_Pin = GPIO_Pin;
}

/*
 * @brief 	Interrupt handler for GPIO.
 *
 * @note 	The function will determine what pin triggered the interrupt and run the
 * 			appropriate code. It will return values defined by the encoderEnum
 * 			enumeration for simplified integration with main code.
 *
 * @param	channel:	The GPIO_pin from the HAL EXTI handler.
 *
 * @retval	encoderEnum
 */


/* USER CODE BEGIN Display Voltage */
/**
* @brief Function displaying voltages, and selecting voltages.
* @param argument: voltages[], int selectedIndex, int selectedVoltage
* @retval None
*/
//void displayVoltages(float voltages[], int selectedIndex, int selectedVoltage){
//	char buffer[50];
//
//	if(selectedVoltage == -1){
//		ssd1306_Fill(Black);
//		ssd1306_SetCursor(5,5);
//		ssd1306_WriteString("Voltage Selection:", Font_6x8 ,White);
//		ssd1306_SetCursor(5,25);
//		sprintf(buffer, "Press encoder to select [%.1f]V", voltages[selectedIndex]);
//		ssd1306_SetCursor(5,45);
//		ssd1306_WriteString("Rotate encoder to see more options", Font_6x8 ,White);
//		ssd1306_UpdateScreen();
//		state = s3;
//	}
//	else{
//		ssd1306_Fill(Black);
//		ssd1306_SetCursor(5,5);
//		sprintf(buffer, "[%.1f]V battery has been selected", voltages[selectedIndex]);
//		ssd1306_UpdateScreen();
//		state = s3;
//	}
//
//}



//gpioGsEnum_e gpioGsFSM(void){
//		// Save the state of the GPIO pins
//		uint8_t clkState = HAL_GPIO_ReadPin(encChanA.GPIOx, encChanA.GPIO_Pin);
//		uint8_t datState = HAL_GPIO_ReadPin(encChanB.GPIOx, encChanB.GPIO_Pin);
//		uint8_t btnState = HAL_GPIO_ReadPin(encChanBtn.GPIOx, encChanBtn.GPIO_Pin);
//		uint8_t estopState = HAL_GPIO_ReadPin(eStop.GPIOx, eStop.GPIO_Pin);
//
//		// Encoder Clockwise or Counterclockwise Turn Detection
//		if(clkState == GPIO_PIN_RESET) {
//			if(datState == clkState){
//				return CwTurn;   // Clockwise Turn
//			}else{
//				return CCwTurn;  // Counterclockwise Turn
//			}
//		}
//
//		// Check if the encoder button is pressed, starts high. If pressed, =0
//		if(btnState == GPIO_PIN_RESET){
//			return enter;
//		}
//
//		// Check if the emergency stop button is pressed
//		if(estopState == GPIO_PIN_RESET){
//			return Estop;
//		}
//
//		// No action detected
//		return none;
//}

gpioGsEnum_e gpioGsFSM(uint16_t channel){
	switch(channel){
	//The case where Channel A triggered the interrupt
	case ENCODER_CHANNEL_A_PIN:

		//Save the state of the encoder pins
		uint8_t clkState = HAL_GPIO_ReadPin(encChanA.GPIOx, encChanA.GPIO_Pin);
		uint8_t datState = HAL_GPIO_ReadPin(encChanB.GPIOx, encChanB.GPIO_Pin);

		/* Explanation of logic:
		 * Since the encoder produces quadrature signals, that means that the
		 * data line will always lead or lag the clock line. Knowing this,
		 * we can reference the data line on the clock line's falling edge.
		 * When the clock line falls, the data line can only assume two states,
		 * it will either be the same as the clock line or opposite the clock line.
		 * Knowing this, the code outputs the appropriate the result corresponding
		 * to the encoder turn.
		 *
		 * Note: In this configuration, the encoder is connected to a pull-up
		 * resistor, so the code analyzes the falling edge.
		 */

		//If the states are the same, it is a clockwise turn
		if(datState == clkState){
			//Cw Rotation
			return CwTurn;

		//If the states are not the same, it is a counterclockwise turn
		}else{
			//Ccw Rotation
			return CCwTurn;
		}
		break;

	//In the case of a button press, output the enter option
	case ENCODER_BUTTON_PIN:
			return enter;
		break;

	//In the case that the emergency stop button was pressed
	case EMERGENCY_STOP_PIN:
		return Estop;

	//Catch-all for values outside of enumerated range
	default:
		break;
	}
	return none;
}




