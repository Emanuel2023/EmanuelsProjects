/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    subghz_phy_app.c
  * @author  MCD Application Team
  * @brief   Application of the SubGHz_Phy Middleware
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "platform.h"
#include "sys_app.h"
#include "subghz_phy_app.h"
#include "radio.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */
#include "LoRa.h"
/* USER CODE END Includes */

/* External variables ---------------------------------------------------------*/
/* USER CODE BEGIN EV */
extern osMessageQueueId_t messageQueueHandle;
extern osMessageQueueId_t signalHandle;
/* USER CODE END EV */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/*Parameter definitions derived from radio.h*/
#define RF_FREQUENCY_HIGH		915000000 	/* 915MHz */
#define RF_FREQUENCY_LOW		433000000	/* 433MHz */
#define TX_OUTPUT_POWER			22			/* [dBm] */

#define LORA_BANDWIDTH 			0			/* [0: 125 kHz, 1: 250 kHz, 2: 500 kHz, 3: Reserved] */

/*Higher Spreading Factor = Longer Range*/
#define LORA_SPREADING_FACTOR	7			/* [6: 64, 7: 128, 8: 256, 9: 512, 10: 1024, 11: 2048, 12: 4096 chips] */
#define LORA_CODINGRATE			2			/* [1: 4/5, 2: 4/6, 3: 4/7, 4: 4/8] */
#define LORA_PREAMBLE_LEN		8			/* Length in symbols (the hardware adds 4 more symbols) */
#define LORA_SYMBOL_TIMEOUT		5			/* RXSingle Time out Value */ /* RX Only */
#define LORA_FIX_LEN_ENABLE		true
#define LORA_FIX_PAYLOAD_LEN	16			/* Length of payload in */ /* RX & TX Only */
#define CRC_ENABLE				false		/* Cyclic Redundancy Check */
#define FREQUENCY_HOP_ENABLE	false
#define FREQUENCY_HOP_PERIOD	0			/* Number of Symbols between each hop. Leave 0 if disabled. */
#define LORA_IQ_INVERT			false		/* Primarily Used in multi-device networks */
#define TX_TIMEOUT				3000		/* [ms] */
#define RX_CONT_ENABLE			true		/* Continuous RX Mode */
#define MAX_TX_BUF 				64
#define SYNCWORD_MAX_LEN 		8
#define MAX_APP_BUFFER_SIZE		255
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* Radio events function pointer */
static RadioEvents_t RadioEvents;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/*!
 * @brief Function to be executed on Radio Tx Done event
 */
static void OnTxDone(void);

/**
  * @brief Function to be executed on Radio Rx Done event
  * @param  payload ptr of buffer received
  * @param  size buffer size
  * @param  rssi
  * @param  LoraSnr_FskCfo
  */
static void OnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t LoraSnr_FskCfo);

/**
  * @brief Function executed on Radio Tx Timeout event
  */
static void OnTxTimeout(void);

/**
  * @brief Function executed on Radio Rx Timeout event
  */
static void OnRxTimeout(void);

/**
  * @brief Function executed on Radio Rx Error event
  */
static void OnRxError(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Exported functions ---------------------------------------------------------*/
void SubghzApp_Init(void)
{
  /* USER CODE BEGIN SubghzApp_Init_1 */

  /* USER CODE END SubghzApp_Init_1 */

  /* Radio initialization */
  RadioEvents.TxDone = OnTxDone;
  RadioEvents.RxDone = OnRxDone;
  RadioEvents.TxTimeout = OnTxTimeout;
  RadioEvents.RxTimeout = OnRxTimeout;
  RadioEvents.RxError = OnRxError;

  Radio.Init(&RadioEvents);

  /* USER CODE BEGIN SubghzApp_Init_2 */
  Radio.SetChannel(RF_FREQUENCY_HIGH);

  Radio.SetTxConfig(MODEM_LORA, TX_OUTPUT_POWER, 0, LORA_BANDWIDTH,
		  LORA_SPREADING_FACTOR, LORA_CODINGRATE, LORA_PREAMBLE_LEN,
		  LORA_FIX_LEN_ENABLE, CRC_ENABLE, FREQUENCY_HOP_ENABLE,
		  FREQUENCY_HOP_PERIOD, LORA_IQ_INVERT, TX_TIMEOUT);

  Radio.SetRxConfig(MODEM_LORA, LORA_BANDWIDTH, LORA_SPREADING_FACTOR,
		  LORA_CODINGRATE, 0, LORA_PREAMBLE_LEN, LORA_SYMBOL_TIMEOUT,
		  LORA_FIX_LEN_ENABLE, LORA_FIX_PAYLOAD_LEN, CRC_ENABLE, FREQUENCY_HOP_ENABLE,
		  FREQUENCY_HOP_PERIOD, LORA_IQ_INVERT, RX_CONT_ENABLE);

  Radio.SetMaxPayloadLength(MODEM_LORA, MAX_APP_BUFFER_SIZE);

  Radio.RxBoosted(0);



  /* USER CODE END SubghzApp_Init_2 */
}

/* USER CODE BEGIN EF */

/* USER CODE END EF */

/* Private functions ---------------------------------------------------------*/
static void OnTxDone(void)
{
  /* USER CODE BEGIN OnTxDone */
	Radio.RxBoosted(0);
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);


  /* USER CODE END OnTxDone */
}

static void OnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t LoraSnr_FskCfo)
{
  /* USER CODE BEGIN OnRxDone */
	/* *payload is the received message. The payload is casted to the lora_msg_s struct
	 * to make data extraction easier. The casted message can then be placed in a
	 * message queue or an external pointer for further use */
	lora_msg_s *msgRx = (lora_msg_s*)payload;
	if(msgRx -> ID == DEVICE_ID){
		osMessageQueuePut(messageQueueHandle, (lora_msg_s*)payload, 0, 0);
		osMessageQueuePut(signalHandle, &rssi,0,0);
	}
	//HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);


  /* USER CODE END OnRxDone */
}

static void OnTxTimeout(void)
{
  /* USER CODE BEGIN OnTxTimeout */
  /* USER CODE END OnTxTimeout */
}

static void OnRxTimeout(void)
{
  /* USER CODE BEGIN OnRxTimeout */
  /* USER CODE END OnRxTimeout */
}

static void OnRxError(void)
{
  /* USER CODE BEGIN OnRxError */
  /* USER CODE END OnRxError */
}

/* USER CODE BEGIN PrFD */

/* USER CODE END PrFD */
