/*
 * VbatADC.h
 *
 *  Created on: Oct 22, 2024
 *  Updated on: Oct 24, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 */

#ifndef INC_VBATADC_H_
#define INC_VBATADC_H_

#include "main.h"

#define	BATTERY_MAX_CHARGE	4.2	/*!< Maximum voltage of Li-Ion and LiPo batteries*/
#define	BATTERY_NOM_CHARGE	3.7	/*!< Nominal voltage of Li-Ion and LiPo batteries*/
#define BATTERY_MIN_CHARGE	3.0	/*!< Minimum voltage of Li-Ion and LiPo batteries*/

typedef struct battery{
	uint8_t	config;				/*!< Number of batteries in series in the battery pack
									 Supported configurations: 2S - 7S*/

	float	voltage;			/*!< Voltage measurement of the battery*/

	uint8_t percent;			/*!< Percent charge of the battery*/
}battery_s;

HAL_StatusTypeDef getBatVolt(battery_s *battery);
void percentConv(battery_s *battery, uint16_t rawVoltage);

#endif /* INC_VBATADC_H_ */
