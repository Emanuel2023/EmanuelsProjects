/*
 * GG_OB_IO.h
 *
 *  Created on: Sep 11, 2024
 *  Updated on: Oct 15, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 */

#ifndef INC_GG_OB_IO_H_
#define INC_GG_OB_IO_H_

typedef enum gpioObEnum{
	none,					/*!< Return status of none in the event of variable
	 	 	 	 	 	 	 	 initialization or if the triggered interrupt is
							 	 not within the bounds of the library*/

	reset1,					/*!< Return status of reset in the event of the
	 	 	 	 	 	 	 	 gpioFSM function detecting the reset switch
	 	 	 	 	 	 	 	 in the active state*/

	enable,					/*!< Return status of enable in the event of the
	 	 	 	 	 	 	 	 gpioFSM function detecting the enable switch
	 	 	 	 	 	 	 	 in the active state*/

	disable					/*!< Return status of enable in the event of the
	 	 	 	 	 	 	 	 gpioFSM function detecting the enable switch
	 	 	 	 	 	 	 	 in the inactive state*/
}gpioObEnum_e;

typedef struct obIO{
	GPIO_TypeDef *GPIOx;	/*!< The GPIO port of the associated channel*/

	uint16_t GPIO_Pin;		/*!< The GPIO pin of the associated channel*/
}obIO_s;

void rstSwInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void enableSwInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void ksInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_TypeDef *GPIOxI, uint16_t GPIO_PinI);

gpioObEnum_e resetSwRead();
gpioObEnum_e enableSwRead();

void Kill_Signal_Write_Pins(GPIO_PinState PinState);
void Speaker_Write_Pin(GPIO_PinState PinState);

#endif /* INC_GG_OB_IO_H_ */
