/*
 * VbatADC.c
 *
 *  Created on: Oct 22, 2024
 *  Updated on: Oct 24, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 */

#include "VbatADC.h"

extern ADC_HandleTypeDef hadc;


/*
 * @brief 	Polls the ADC for the battery voltage
 *
 * @note	Calling this function will call all the necessary functions
 * 			to acquire the battery voltage from the ADC. Depending on
 * 			the resolution required, the ADC resolution can be adjusted
 * 			to meet the spec. I have included a table of comparing the
 * 			number of bits to voltage step size to help with the selection
 * 				6-bit  = 51.6mV/step
 * 				8-bit  = 11.7mV/step
 * 				10-bit = 2.9mV/step
 * 				12-bit = 0.7mV/step
 *
 * @param	*battery: pointer to the battery instance's data structure
 *
 * @retval	HAL_StatusTypeDef
 */
HAL_StatusTypeDef getBatVolt(battery_s *battery){
	//Start ADC conversion
	if(HAL_ADC_Start(&hadc) != HAL_OK){
		//Output error code if something went wrong
		return HAL_ERROR;
	}

	//Poll ADC for conversion
	if(HAL_ADC_PollForConversion(&hadc, 1) != HAL_OK){
		//Output error code if something went wrong
		return HAL_ERROR;
	}

	//Save the ADC value
	uint16_t rawVolt = HAL_ADC_GetValue(&hadc);

	percentConv(battery, rawVolt);
	return HAL_OK;
}

/*
 * @brief 	Converts raw ADC readings into calibrated voltage and percent
 * 			charge calculations
 *
 * @param	*battery: Pointer to the battery instance's data structure
 *
 * @param	rawVoltage: raw ADC measurement
 *
 * @note	This function takes in the battery structure and raw voltage
 * 			measurement and applies two formulae to calculate the voltage
 * 			and percent charge. The equations are included in the function
 * 			comments.
 *
 * @retval	void
 */
void percentConv(battery_s *battery, uint16_t rawVoltage){

	float voltage = rawVoltage;

	/* Converting the raw ADC reading to voltage using the equation
	 * (ADC Reading / Max ADC Value) * Max ADC Voltage * Resistor Divider Value
	 * (ADC Reading / Max ADC Value) * 3.3v * 10
	 */
	if(hadc.Init.Resolution == ADC_RESOLUTION_12B){
		voltage = (voltage/4096)*33;
	}
	else if(hadc.Init.Resolution == ADC_RESOLUTION10b){
		voltage = (voltage/1024)*33;
	}
	else if(hadc.Init.Resolution == ADC_RESOLUTION8b){
		voltage = (voltage/256)*33;
	}
	else if(hadc.Init.Resolution == ADC_RESOLUTION6b){
		voltage = (voltage/64)*33;
	}
	else{
		//There's literally no way you can get here so I'm
		//not going to bother putting any code.
	}
	battery->voltage = voltage;
	/* Calculates the current battery percentage by assigning the
	 * maximum and minimum voltage range and returning the percentage
	 * within that range using the following equation
	 *
	 * ((battery voltage - minimum voltage)/(maximum voltage - minimum voltage))*100
	 */
	battery->percent = ((battery->voltage - (BATTERY_MIN_CHARGE * battery->config))/((BATTERY_MAX_CHARGE * battery->config) - (BATTERY_MIN_CHARGE * battery->config)))*100;

}
