/*
 * gg_ob_io.c
 *
 *  Created on: Sep 11, 2024
 *  Updated on: Oct 15, 2024
 *      Author: Dalen Ricks
 *
 *      This library was created to be used in the Genysis Guard system as a
 *      part of the UTSA Skynet Senior Design group.
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include "main.h"
#include "gg_ob_io.h"

obIO_s rstSw;
obIO_s enSw;
obIO_s killSig;
obIO_s killSigInv;

extern TIM_HandleTypeDef htim16;

/*
 * @brief 	Function to initialize the reset switch.
 *
 * @note 	This switch is to reset the system after entering recovery mode.
 *
 * @param	GPIOx: The port of the channel that the reset switch is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the reset switch is attached to
 *
 * @retval	none
 */
void rstSwInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	rstSw.GPIOx = GPIOx;
	rstSw.GPIO_Pin = GPIO_Pin;
}


/*
 * @brief 	Function to initialize the enable switch.
 *
 * @note 	This switch is to enable the on board device for pairing and activation.
 *
 * @param	GPIOx: The port of the channel that the enable switch is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the enable switch is attached to
 *
 * @retval	none
 */
void enableSwInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin){
	enSw.GPIOx = GPIOx;
	enSw.GPIO_Pin = GPIO_Pin;
}


/*
 * @brief 	Function to initialize the kill signals.
 *
 * @note 	These are the non-inverted and inverted kill signals for the on-board device.
 *
 * @param	GPIOx: The port of the channel that the kill signal is attached to
 *
 * @param	GPIO_Pin: The pin of the channel that the kill signal is attached to
 *
 * @param	GPIOxI:	The port of the channel that the inverted kill signal is attached to
 *
 * @param	GPIO_PinI: The pin of the channel that the inverted kill signal is attached to
 *
 * @retval	none
 */
void ksInit(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_TypeDef *GPIOxI, uint16_t GPIO_PinI){
	killSig.GPIOx = GPIOx;
	killSig.GPIO_Pin = GPIO_Pin;
	killSigInv.GPIOx = GPIOxI;
	killSigInv.GPIO_Pin = GPIO_PinI;

	//Initializing the kill signal states
	Kill_Signal_Write_Pins(0);
}

/*
 * @brief 	Reads the state of the reset switch.
 *
 * @note	This function will return the appropriate enumeration
 * 			to ease integration into Genysis Guard state machine.
 *
 * @retval	gpioObEnum_e (none/reset)
 */
gpioObEnum_e resetSwRead(){
	if(HAL_GPIO_ReadPin(rstSw.GPIOx, rstSw.GPIO_Pin) == 1){
		return reset1;
	}else{
		return none;
	}
}

/*
 * @brief 	Reads the state of the enable switch.
 *
 * @note	This function will return the appropriate enumeration
 * 			to ease integration into Genysis Guard state machine.
 *
 * @retval	gpioObEnum_e (disable/enable)
 */
gpioObEnum_e enableSwRead(){
	if(HAL_GPIO_ReadPin(enSw.GPIOx, enSw.GPIO_Pin) == 1){
		return enable;
	}else{
		return disable;
	}
}

/*
 * @brief 	Sets the pin state of the kill signals.
 *
 * @note	You write the non-inverted pin state and the function will ensure the
 * 			kill signal pins are always complementary.
 *
 * @param	PinState:	The state that the kill signals will be set to
 *
 * @retval	none
 */
void Kill_Signal_Write_Pins(GPIO_PinState PinState){
	HAL_GPIO_WritePin(killSig.GPIOx, killSig.GPIO_Pin, PinState);
	HAL_GPIO_WritePin(killSigInv.GPIOx, killSigInv.GPIO_Pin, !PinState);
}

/*
 * @brief 	Turns on or off the speaker.
 *
 * @note	This function will modify the duty cycle of the PWM
 * 			timer to be either 0% or 50% to turn on and off the speaker
 * 			You set the Capture Compare Register (CCRx) to 50% by
 * 			retrieving the period from the Auto-Reload Register (ARR)
 * 			and dividing it by 2, then adding 1.
 *
 * @param	PinState:	The state that the kill signals will be set to
 *
 * @retval	none
 */
void Speaker_Write_Pin(GPIO_PinState PinState){
	if(PinState == 1){
		//Set PWM duty cycle to 50%
		__HAL_TIM_SET_COMPARE(&htim16, TIM_CHANNEL_1, 125);

		//Direct register addressing approach
		//pwmTim.Instance -> CCR2 = (((TIM1 -> ARR)/2) + 1);

	}else{
		//Set PWM duty cycle to 0%
		__HAL_TIM_SET_COMPARE(&htim16, TIM_CHANNEL_1, 0);

		//Direct register addressing approach
		//TIM1 -> CCR2 = 0;
	}
}
