/*
 * LoRa.c
 *
 *  Created on: Mar 6, 2024
 *      Author: super
 */

#include "LoRa.h"
#include "M10S.h"
#include "gg_ob_io.h"
#include "VbatADC.h"


extern bool heartbeat_received;
extern bool handshake_received;
extern uint8_t M10S_received_buffer_RX[36];
extern uint8_t M10S_RX_complete_flag;
battery_s batteryInstance;





//Function to initialize the radio communication
void init(){

	SubghzApp_Init();

}
void handshake(){
	Kill_Signal_Write_Pins(0);
	lora_msg_s Handshake;
	Handshake.ID = Ground_Station;
	Handshake.msg_id= ns_ack;
	//uint8_t buffer [sizeof(Handshake)];
	//send connection to on board

	//Serialize data in Kill_Command to be sent over
	radio_status_t status = Radio.Send((uint8_t*)&Handshake, sizeof(Handshake));

	//Radio.Send(buffer, sizeof(buffer));

}
//Function to send heartbeat packet including Battery, GPS coordinates, and RSSI
void send_heartBeat(){
	lora_msg_s heartbeat;
	batteryInstance.config = 2;
	getBatVolt(&batteryInstance);


	heartbeat.ID = Ground_Station;
	heartbeat.msg_id = Heartbeat;
	heartbeat.state_id = s3;
//	heartbeat.gps_long = 0;//Place holder data for debugging
//	heartbeat.gps_lat = 0; //Placeholder data for debugging
	heartbeat.b_percentage = batteryInstance.percent;
	//heartbeat.b_percentage = 70;
	heartbeat.b_voltage = batteryInstance.voltage;

	getGPS(&heartbeat);

	if((heartbeat.gps_lat !=0) &&(heartbeat.gps_long !=0)){
		printf("Latitude: %ld\t     Longitude: %ld\t\n\r", heartbeat.gps_lat, heartbeat.gps_long);
		radio_status_t status = Radio.Send((uint8_t*)&heartbeat, sizeof(heartbeat));
		printf("Radio send?: %d\n\r", status);
	}
//
//	printf("Latitude: %ld\t     Longitude: %ld\t\n\r", heartbeat.gps_lat, heartbeat.gps_long);
//	radio_status_t status = Radio.Send((uint8_t*)&heartbeat, sizeof(heartbeat));
//	printf("Radio send?: %d\n\r", status);




		//Error Handler
		//Turns on red LED in event of error
//		if (status != RADIO_STATUS_OK)
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
}



//Function to execute upon receiving kill command from ground station
void arm(){

	//Turn on Red LED
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
	Kill_Signal_Write_Pins(1);
	Speaker_Write_Pin(1);
	if(resetSwRead() == reset1){
		Speaker_Write_Pin(0);
	}



}

//Function to check if onboard is receiving messages from GS.
void check_connection(){

	int counter=0;
	int max_count=10; //Max number of missed messages

	for(int i=0;i<max_count;++i)
	{
		if (heartbeat_received)
		{
			heartbeat_received = 0; //Sets heartbeat indicator back to 0
			counter = 0; //Resets count
			break;
		}
		++counter; //Increments counter
		if (counter >= 9)
			arm(); //Triggers termination
		osDelay(300); //This delay can be adjusted to increase "loss of connection time" allowed

		//If using osDelay(x), allowable time without connection is roughly x*10 ms
		//Example: using osDelay(300) termination after approximately 3 seconds
	}
}

//Reset system
void reset(){
    lora_msg_s reset;
    reset.ID = Ground_Station;
    reset.msg_id = recover;
    reset.state_id = s1;
    reset.gps_lat=0;
    reset.gps_long=0;

    radio_status_t status = Radio.Send((uint8_t*)&reset, sizeof(reset));
}
void disableOn(){
	lora_msg_s enSwitch;
	enSwitch.ID = Ground_Station;
	enSwitch.msg_id = Reset;
	enSwitch.state_id = s4;
	enSwitch.gps_long = 0xFF;//Place holder data for debugging
	enSwitch.gps_lat = 0xFF; //Placeholder data for debugging
	enSwitch.b_percentage = 0xFF;
	enSwitch.b_voltage = 0xFF;
	radio_status_t status = Radio.Send((uint8_t*)&enSwitch, sizeof(enSwitch));

}

//Function to get GPS coordinates
void getGPS(lora_msg_s *inst){

	if (M10S_RX_complete_flag == 1)
	{
		M10S_RX_complete_flag = 0;
		if (M10S_UBX_CHKSUM_Check(&M10S_received_buffer_RX[0],36) == 1)
		{
			M10S_UBX_NAV_POSLLH_Parsing(&M10S_received_buffer_RX[0], &posllh_structure_variable);
			inst -> gps_lat = posllh_structure_variable.latitude;
			inst -> gps_long= posllh_structure_variable.longitude;

//			printf("Latitude: %ld\t     Longitude: %ld\t\n\r", posllh_structure_variable.latitude, posllh_structure_variable.longitude);
    		printf("Latitude: %ld\t     Longitude: %ld\t\n\r", inst -> gps_lat, inst -> gps_long);
		}
	}
}

//Function for bluetooh
void getBLE(){

}

void send_ack(){

	lora_msg_s ack;

	ack.ID = Ground_Station;
	ack.msg_id = ns_ack;
	ack.state_id = s2;
	ack.gps_lat=0;
	ack.gps_long=0;

	radio_status_t status = Radio.Send((uint8_t*)&ack, sizeof(ack));
}


//Input parameters not needed if using a message queue
void processData(){
	lora_msg_s in;
	lora_msg_s out;

	osMessageQueueGet(messageQueueHandle, &in, 0, osWaitForever);

	if(enableSwRead()== enable){
		switch(in.msg_id){
		case Init:
			init();
			break;
		case Heartbeat:
			if(resetSwRead()== reset1){
				HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_15);
				for (int i =0; i <10; i++){
					reset();
				}
				heartbeat_received = true;//Used to check if there is connection between GS and onboard
				HAL_GPIO_WritePin(Recovery_GPIO_Port, Recovery_Pin,0);
			}
			else if (in.gps_long == 1)
				Speaker_Write_Pin(1);
			else
				Speaker_Write_Pin(0);
			break;
		case Arm:
			arm();
			break;
		case Reset:
			reset();
		case HS:
			send_ack();
			handshake_received = true;
			break;
		}
	}
	else{
		disableOn();
	}
}


